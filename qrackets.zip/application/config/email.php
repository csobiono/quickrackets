<?php
$config['protocol']     = 'smtp';
$config['smtp_host']    = 'smtp.quickrackets.com';
$config['smtp_port']    = '587';
$config['smtp_user'] 	= 'service@quickrackets.com';
$config['smtp_pass'] 	= 'Takemetothem00n@123';
$config['smtp_timeout'] = 30;
$config['newline']      = "\r\n";
$config['crlf']         = "\r\n";
$config['mailtype']     = 'html';
$config['charset']      = 'utf-8'; 
?>