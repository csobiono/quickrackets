$(document).ready(function(){
	$(".root").text('Events');
	$(".root").css("background-image", "url('/themes/images/nav-icons/top-nav/events-root.png')")
	$('#events-link').addClass('current');
})