$(document).ready(function(){
	$(".root").text('My Money');
	$(".root").css("background-image", "url('/themes/images/nav-icons/top-nav/funds-root.png')")
	$('#funds-link').addClass('current');
	$(".notice").remove()
})