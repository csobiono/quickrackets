$(document).ready(function(){
	$("#misc").css('display','none')
	$(".root").text('My Groups');
	$(".root").css("background-image", "url('/themes/images/nav-icons/top-nav/groups-root.png')")
	$('#groups-link').addClass('current');
})