$(document).ready(function(){

    $("#select_month").change(function () {
        
        $('#target').submit();
    });
    $("#select_year").change(function () {
        
        $('#target').submit();
    });
    $("#select_user").change(function () {
        $('#target').submit();
    });
});