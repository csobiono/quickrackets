Enhance applications with 24x24 pixel icons for absolutely free! 
Including a variety of toolbar icons, the 24x24 Free Pixel Icons 
set features dozens of images commonly used in applications, 
including New, Open, Save, Cut, Copy, Paste, and so on.

These free icons are available in two states, normal and disabled, 
and in two color schemes, 256 colors and 32-bit color. The file formats 
are PNG, BMP, GIF and ICO. It is available for instant free download.

more information here: http://www.small-icons.com/packs/24x24-free-pixel-icons.htm