<?php

define ('FILE_CACHE_DIRECTORY', '../system/cache/timthumb');

?>